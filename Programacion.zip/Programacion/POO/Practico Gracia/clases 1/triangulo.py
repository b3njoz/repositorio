class triangulo:
    def __init__(self, ladoA,ladoB,ladoC):
        self.ladoA = ladoA
        self.ladoB = ladoB
        self.ladoC = ladoC
        
    def perimetro(self):
        per = self.ladoA + self.ladoB + self.ladoC
        print(per)
        
    def esEquilatero(self):
        if self.ladoA == self.ladoB == self.ladoC:
            return True
    
    def esIsosceles(self):
        if self.ladoA == self.ladoB and self.ladoA != self.ladoC:
            return True
        elif self.ladoA == self.ladoC and self.ladoA != self.ladoB:
            return True
        elif self.ladoB == self.ladoC and self.ladoB != self.ladoA:
            return True
        elif self.ladoB == self.ladoA and self.ladoB != self.ladoC:
            return True
        elif self.ladoC == self.ladoA and self.ladoC != self.ladoB:
            return True

    def esEscaleno(self):
        if self.ladoA != self.ladoB != self.ladoC:
            return True
            
    
triangule = triangulo(1,2,1)
print(triangule.esIsosceles())
print(triangule.esEscaleno())
print(triangule.esEquilatero())
triangule.perimetro()
