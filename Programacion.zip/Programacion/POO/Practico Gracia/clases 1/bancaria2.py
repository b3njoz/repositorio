class cuentaBancaria:
    def __init__(self, nombre, apellido, nrocuenta, saldo=0):
        self.nombre = nombre
        self.apellido = apellido
        self.nrocuenta = nrocuenta
        self.saldo = saldo
        self.ingresos = []
        self.retiro = []
        
    def __str__(self):
        return f"{self.apellido}, {self.nombre}. Nro de cuenta: {self.nrocuenta}, Saldo: ${self.saldo}, {self.retiro}. {self.ingresos}"
    
    def ingresar(self, monto):
        if monto > 0:
            self.saldo += monto
        self.ingresos.append(monto)
            
    def retirar(self,monto):
        if monto > 0:
            self.saldo -= monto
        self.retiro.append(monto)
    
    def verHistorial(self):
        return f"Historial de Ingresos: {self.ingresos}.\nHistorial de retiro: {self.retiro}"
            
            
cuenta = cuentaBancaria("Benjamin", "Ortiz", 123)
cuenta.ingresar(1000)
cuenta.ingresar(90)
cuenta.ingresar(595)
cuenta.retirar(1100)
cuenta.retirar(1100)
cuenta.retirar(1100)
cuenta.retirar(1100)
cuenta.retirar(111)
print(cuenta.verHistorial())

print(cuenta)