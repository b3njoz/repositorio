class cuentaBancaria:
    def __init__(self, nombre, apellido, nrocuenta, saldo=0):
        self.nombre = nombre
        self.apellido = apellido
        self.nrocuenta = nrocuenta
        self.saldo = saldo
        
    def __str__(self):
        return f"{self.apellido}, {self.nombre}. Nro de cuenta: {self.nrocuenta}, Saldo: ${self.saldo}"
    
    def ingresar(self, monto):
        if monto > 0:
            self.saldo += monto
    
    def retirar(self,monto):
        if monto > 0:
            self.saldo -= monto
            
cuenta = cuentaBancaria("Benjamin", "Ortiz", 123)
cuenta.ingresar(1000)
cuenta.retirar(1100)


print(cuenta)