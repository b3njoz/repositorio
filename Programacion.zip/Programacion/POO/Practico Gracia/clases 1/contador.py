class Contador:
    def __init__(self, cuenta=0):
        self.cuenta = cuenta
        
    def mostrar(self):
        print(self.cuenta)
    
    def incrementar(self, valor = 1):
        if valor > 1:
            self.cuenta += valor
        else:
            self.cuenta += 1
        print(self.cuenta)
        
    def decrementar(self, valor = 1):
        if valor > 1:
            self.cuenta -= valor
        else:
            self.cuenta -= 1
        print(self.cuenta)
    
    def reiniciar(self):
        self.cuenta = 0    
    
cuenta = Contador()

cuenta.mostrar()
cuenta.incrementar(23)
cuenta.decrementar()
cuenta.reiniciar()
cuenta.mostrar()
