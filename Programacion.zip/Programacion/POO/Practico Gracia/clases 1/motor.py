class Motor:
    def __init__(self,nivel_aceite,temperatura,encendido=False):
        self.nivel_aceite = nivel_aceite
        self.temperatura = temperatura
        self.encendido = encendido
    
    def arrancar(self):
        if encendido == False:
            encendido = True
        else:
            print("El auto esta encendido")
    
    def detener(self):
        if encendido == True:
            encendido = False
        else:
            print("El auto esta apagado")
            
class Rueda:
    def __init__(self, rodado, presion):
        self.rodado = rodado
        self.presion = presion
    
    def inflar(self,aire):
        self.presion += aire
        
    def desinflar(self,aire):
        self.presion -= aire
    
class Ventana:
    def __init__(self,polazirado):
        self.polarizado = polazirado
        
    def abrir(self):
        print("Abierto")
        
    def cerrar(self):
        print("Cerrado")
        
class Puerta(Ventana):
    def __init__(self,color,polarizado):
        super().__init__(polarizado)
        self.color = color
    
    def abrir(self):
        super().abrir()
        
    def cerrar(self):
        super().cerrar()
    
class Auto(Motor,Rueda,Ventana,Puerta):
    pass