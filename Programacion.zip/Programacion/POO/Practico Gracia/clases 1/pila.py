class Pila:
    def __init__(self):
        self.lista = []
    
    def agregar(self, elemento):
        self.lista.append(elemento)
    
    def quitar(self):
        elemento = self.lista.pop()
        return f"Se quita: {elemento}"
    
    def estaVacia(self):
        if len(self.lista) == 0:
            return True
        else:
            return False
    
    def cantidad(self):
        return f"Cantidad de elementos ingresados {len(self.lista)}"
    
    def __str__(self):
        return f"{self.lista}"
        
lista = Pila()
print(lista.estaVacia())
lista.agregar(1)
lista.agregar(2)
lista.agregar(3)
lista.agregar(4)
print(lista.quitar())
print(lista.cantidad())

print(lista)