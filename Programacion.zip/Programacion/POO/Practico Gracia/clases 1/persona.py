class Persona:
    def __init__(self, nombre, apellido, edad, altura, peso):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.altura = altura
        self.peso = peso
        
    def nombreCompleto(self):
        return f"{self.apellido}, {self.nombre}"
    
    def esMayor(self):
        if self.edad >= 18:
            return True
        
    def imc(self):
        imc= self.peso/(self.altura**2)
        return f"El imc es de {imc}"
    
    def __str__(self):
        return f"{self.apellido}, {self.nombre}. {self.edad} años {self.altura}m {self.peso}kg"
    
Benja = Persona("Benjamin", "Ortiz", 23, 1.74, 86)

print(Benja.nombreCompleto())
print(Benja.esMayor())
print(Benja.imc())
print(Benja)
