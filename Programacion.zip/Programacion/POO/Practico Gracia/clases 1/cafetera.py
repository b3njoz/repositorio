class Cafetera:
    def __init__(self, capacidadMaxima=1000, capacidadActual=0):
        self.capacidadActual = capacidadActual
        self.capacidadMaxima = capacidadMaxima
        
    def llenar(self):
        if self.capacidadActual == 1000:
            print("Cafetera llena")
        else:
            self.capacidadActual = 1000
            print(self.capacidadActual)
        
    def servir(self, cantidad):
        if cantidad > 0 and cantidad == self.capacidadMaxima:
            self.capacidadActual += cantidad
        print(self.capacidadActual)
        
    def vaciar(self):
        self.capacidadActual = 0
        print(self.capacidadActual)
    
    def agregar(self, cantidad):
        if cantidad > 0 and cantidad < self.capacidadMaxima:
            self.capacidadActual = cantidad
        print(self.capacidadActual)
        
cafe = Cafetera()

cafe.llenar()
cafe.llenar()
cafe.vaciar()
cafe.servir(1000)
cafe.llenar()
cafe.agregar(10)