import math

class circulo:
    def __init__(self, radio):
        self.radio = radio
        
    def area(self):
        area = math.pi*(self.radio**2)
        print(area)
    
    def perimetro(self):
        per = (2*math.pi*self.radio)
        print(per)
        
circle = circulo(5)
circle.area()
circle.perimetro()