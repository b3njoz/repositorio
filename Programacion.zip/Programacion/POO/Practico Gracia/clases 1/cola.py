class Cola:
    def __init__(self):
        self.lista = []
        
    def agregar(self,elemento):
        self.lista.append(elemento)
    
    def quitar(self):
        elemento = self.lista.pop(0)
        return elemento
    
    def estaVacia(self):
        if len(self.lista) == 0:
            return True
        else:
            return False
    
    def cantidad(self):
        return f"La cantidad de elementos ingresados es: {len(self.lista)}"
    
    def __str__(self):
        return f"{self.lista}"
    
lista = Cola()
lista.agregar(1)
print(lista.estaVacia())
lista.agregar(2)
lista.agregar(3)
lista.agregar(4)
lista.quitar()
print(lista)