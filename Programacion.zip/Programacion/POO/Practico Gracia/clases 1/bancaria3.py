class CuentaBancaria:
    def __init__(self, nombre, apellido,saldo):
        self.nombre= nombre
        self.apellido = apellido
        self.saldo = saldo
    
    def __str__(self):
        return f"{self.nombre}, {self.apellido}. Saldo: ${self.saldo}."
    
    def saldo(self):
        print(f"El saldo de la cuenta es: ${self.saldo}")
    
    def ingresar(self,monto):
        if monto > 0:
            self.saldo += monto
        else:
            print("El monto es negativo")
            
    def retirar(self, monto):
        if monto > 0:
            self.saldo -= monto
        else:
            print("El monto ingresado es negativo")
    
class CuentaAhorro(CuentaBancaria):
    def __init__(self, nombre,apellido,saldo, estado=False):
        super().__init__(nombre,apellido,saldo)
        self.estado = estado
        if self.saldo >= 10000:
            self.estado = True
        
    def ingresar(self, monto):
        super().ingresar(monto)
        
    def retirar(self, monto):
        if self.estado == True:
            super().retirar(monto)
        else:
            print(f'la cuenta esta inactiva, no se puede retirar')
    
    def __str__(self):
        return f"{super().__str__()} Activa:{self.estado}"
    
class CuentaCorriente(CuentaBancaria):
    def __init__(self,nombre,apellido,saldo,sobregiro=0):
        super().__init__(nombre,apellido,saldo)
        self.sobregiro = sobregiro
        
    def ingresar(self,monto):
        if self.sobregiro > 0:
            self.sobregiro -= monto
        else:
            super().ingresar(monto)
    
    def retirar(self,monto):
        if monto <= self.saldo:
            super().retirar(monto)
        else:
            self.sobregiro += monto - self.saldo
    
    def __str__(self):
        return f"{super().__str__()} Sobregiro: ${self.sobregiro}"
    
        
#benja = CuentaAhorro("benja","ortiz",111100)
#print(benja)
#benja.retirar(200)
#print(benja)

benja2 = CuentaCorriente("benjo","ort", 0)
benja2.ingresar(200)
benja2.retirar(500)
print(benja2)