class TiendaOnline:
    def __init__(self,nombre_tienda,ubicacion,ventas_mensuales):
        self.nombre_tienda = nombre_tienda
        self.productos_disponibles = ['tele','mouse','teclado','pc']
        self.ubicacion = ubicacion
        self.ventas_mensuales = ventas_mensuales
    
    def buscar_producto(self,producto):
        if producto in self.productos_disponibles:
            print("producto disponible")
        else:
            print("no se encuentra disponible")
    
    def calcular_descuento(self, monto_compra):
        if monto_compra >= 100:
            monto_compra -= monto_compra *0.10
            print(monto_compra)
        elif monto_compra >= 200:
            monto_compra -= monto_compra * 0.20
            print(monto_compra)
    
minimarket = TiendaOnline("Kari","La Rioja",2000)
minimarket.buscar_producto("mouse")
minimarket.calcular_descuento(200)