import math

class complejo:
    def __init__(self, real, imaginario):
        self.real = real
        self.imaginario = imaginario
    
    def mostrar(self):
        print(self.real, self.imaginario)
        
    def modulo(self):
        m = math.sqrt(self.real*self.real + self.imaginario*self.imaginario)
        return m
    
num = complejo(4,7)

num.mostrar()
print(num.modulo())
