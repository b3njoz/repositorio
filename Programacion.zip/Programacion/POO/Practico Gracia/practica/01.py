def mostrar_mensaje(mensaje):
    print(mensaje)
    
mostrar_mensaje(345353)

def sumar(a,b):
    suma=a+b
    return suma

resultado = sumar(12, 4)
print(resultado)