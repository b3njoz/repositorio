class Estudiante:
    def __init__(self,nombre,edad,promedio,carrera):
        self.nombre = nombre
        self.edad = edad
        self.promedio = promedio
        self.carrera = carrera
        
    def verificar_aprobacion(self):
        if self.promedio >= 70:
            return print("Apronado")
        else:
            return print("Reprobado")
        
    def es_mayor_de_edad(self):
        if self.edad >= 18:
            return print("Es mayor")
        else:
            return print("Es menor")
        
    def __str__(self):
        return f"{self.nombre}, {self.edad}. {self.promedio}, {self.carrera}"
    
benja = Estudiante("benja", 23, 60, "Tecnicatura en programacion")

benja.verificar_aprobacion()
benja.es_mayor_de_edad()
print(benja)