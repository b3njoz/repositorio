class Coche:
    def __init__(self,marca,modelo,año,velocidad=0):
        self.marca = marca
        self.modelo = modelo
        self.año = año
        self.velocidad = velocidad
        
    def acelerar(self,aceleracion):
        self.velocidad += aceleracion
        return print(f"La velocidad actual del auto es: {self.velocidad}km/h")
    
    def frenar(self,freno):
        self.velocidad -= freno
        return print(f"El auto freno y su velocidad actual es de: {self.velocidad}km/h")
    
fitito = Coche("Fiat",600, 73)

fitito.acelerar(100)
fitito.frenar(10)