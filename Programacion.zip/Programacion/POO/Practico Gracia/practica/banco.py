class Banco:
    def __init__(self,nombre,saldo=[],interes= 110,cliente=[]):
        self.nombre = nombre
        self.saldo = saldo
        self.interes = interes
        self.cliente = cliente
        self.saldoc = []
    
    def clientes(self,usuario,monto):
        self.cliente.append(usuario)
        self.saldoc.append(monto)
        
    def intereses(self,monto):
        self.interes /= (monto * 30)
        return print(f"El interes mensual con {monto}, es de {self.interes}")
    
    def __str__(self):
        return f"{self.nombre} {self.saldo} {self.interes} {self.cliente} {self.saldoc}"
    
bbva = Banco("BBVA",1000)

bbva.clientes("benja",8)

print(bbva)