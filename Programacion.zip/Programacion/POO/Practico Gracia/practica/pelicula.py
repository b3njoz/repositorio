class Pelicula:
    def __init__(self,titulo,director,duracion,genero):
        self.titulo = titulo
        self.director = director
        self.duracion = duracion
        self.genero = genero
        self.lista = []
        
    def reproducir(self):
        return f"Se empezo a reproducir: {self.titulo}, con una duracion de {self.duracion}h"
    
    def recomendacion(self):
        