class ProductoElectronico:
    def __init__(self,nombre,marca,precio,disponibilidad=True):
        self.nombre = nombre
        self.marca = marca
        self.precio = precio
        self.disponibilidad = disponibilidad
        
    def compra(self):
        if self.disponibilidad == True:
            self.disponibilidad = False
            print(f"Se compro: {self.marca} {self.nombre} a {self.precio}")
        else:
            print("El producto no esta disponible")
        
    def garantia(self,dias):
        if dias > 30:
            print("Se supero el tiempo de garantia")
        else:
            print("El producto esta en garantia")
            
Telefono = ProductoElectronico("S23","Samsung", 2000)

Telefono.compra()
Telefono.garantia(12)
