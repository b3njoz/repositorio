class Libro:
    def __init__(self,titulo,autor,año,disponible=True):
        self.titulo = titulo
        self.autor = autor
        self.año = año
        self.disponible = disponible
        
    def solicitar_prestamo(self):
        if self.disponible == True:
            print("Se presta el libro")
            self.disponible = False
        else:
            print("El libro no esta disponible")
        
    def devolver_libro(self, dias):
        if dias > 15:
            print("Debera pagar una multa de 500 pesos")
        else:
            print("Se devolvio el libro")
    
harry_potter = Libro("Harry Potter", "No se", 2000)

harry_potter.solicitar_prestamo()
harry_potter.devolver_libro(16)