class IndicePeliculas():
    def __init__(self, lista_peliculas) -> None:
        self.lista_peliculas = lista_peliculas

    def busqueda_genero(self, genero):
        lista_recomendacion = []
        for pelicula in self.lista_peliculas:
            if pelicula.genero == genero:
                lista_recomendacion.append(pelicula.titulo)
        return f"Te recomendamos en base a ese genero {lista_recomendacion}"
    
    def __str__(self):
        return f"{self.lista_peliculas}"


class Pelicula():
    def __init__(self, titulo, director, duracion, genero):
        self.titulo = titulo
        self.director = director
        self.genero: str = genero
        self.duracion = duracion

    def reproducir(self):
        return f'La pelicula es: {self.titulo} y su tiempo de duracion es de: {self.duracion}min, su genero es: {self.genero}'
    
    def __str__(self):
        return f"{self.titulo} {self.director} {self.genero} {self.duracion}"
    
duro_de_matar = Pelicula("Duro de Matar", "John Moore", "2h 12m", "Accion")

john_wick = Pelicula("John Wick", "Keanu Reaves", "4h 12m", "Accion")

alien = Pelicula("Alien", "Ridley Scott", "1h 57m", "Terror")

que_paso_ayer = Pelicula("Que Paso Ayer", "Todd Philips", "1h 40m", "Comedia")

lista_peliculas = [alien, duro_de_matar, que_paso_ayer, john_wick]
indice = IndicePeliculas(lista_peliculas)


lista_peliculas
print(indice.busqueda_genero("Accion"))
