//js + xml

//Componente
function MiComponente(props){
  const {mensaje, mensaje2, numero} = props;
  return(
    <p>
      {mensaje}, {mensaje2}, {numero %2==0 ? 'par' : 'impar'}
    </p>
  )
}

//Otro Componente
function Otro(props){
  return <p>{props.children}</p>;
}

//Componente de Aplicacion
function App() {
  const mensaje = "anashi";
  return (
    <>
    <h1>Hola</h1>
    <p>{mensaje}</p>
    <MiComponente mensaje="Hola" mensaje2={true} numero={5}/>
    <MiComponente mensaje="desde" mensaje2={2} numero={6}/>
    <MiComponente mensaje="componente" mensaje2={mensaje} numero={-10}/>
    <Otro></Otro>
    </>
  )
}


export default App
