import mensajeAAAAAA, {numero, palabra, arreglo, objeto, mostrar} from "./extras.js"


console.log(numero);
console.log(palabra);
console.log(arreglo);
console.log(objeto);
mostrar("en main");
console.log(mensajeAAAAAA)