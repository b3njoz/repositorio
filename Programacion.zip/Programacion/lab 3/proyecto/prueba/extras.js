export const numero = 3;
export const palabra = "extras";
export const arreglo = [1,2,3];
export const objeto = { nombre: "pepe", apellido: "sanchez", edad: 30};
export function mostrar(mensaje){
    console.log(mensaje);
}
const mensaje = "hola";

export default mensaje;