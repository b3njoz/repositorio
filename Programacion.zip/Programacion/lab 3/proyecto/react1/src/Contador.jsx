import { useState } from "react";

function Contador(){
    const [cuenta, setCuenta] = useState(0)
    
    const incrementar = () =>{
        setCuenta(cuenta + 1)
    };
    return(
    <>
        <p>{cuenta}</p>
        <button onClick={incrementar}>Incrementar</button>
        <button onClick={()=> setCuenta(cuenta-1)}>Decrementar</button>
    </>
    )
}

export default Contador
