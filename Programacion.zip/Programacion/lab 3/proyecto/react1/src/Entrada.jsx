import { useState } from "react";

function Entrada(){
    const [texto, setTexto] = useState("");
    const [entrada, setEntrada] = useState("");

    const modificar = () =>{
        setTexto(entrada);
    }
    return(
    <>
        <input value={entrada} onChange={(e)=>setEntrada(e.target.value)} />
        <button onClick={modificar}>Modificar</button>
        <p>Texto ingresado: {texto}</p>
    </>
    )
}

export default Entrada
