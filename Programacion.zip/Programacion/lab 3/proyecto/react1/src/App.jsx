import Numero from "./Numero";

function App() {
  return (
    <>
    <Numero/>
    </>
  )
}

export default App
