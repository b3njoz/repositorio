import Botones from "./Botones"
import Imc from "./Imc"
import Formulario from "./Formulario"
import modificarDiv from "./prueba"

function App() {
  return (
    <>
    <modificarDiv></modificarDiv>
    </>
  )
}

export default App
