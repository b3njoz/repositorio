import { useState } from "react"

export default function modificarDiv(){

    const [direccion, setDireccion] = useState("row")
    const [justificado, setJustificado] = useState("center")
    const [alineado, setAlineado] = useState("center")


    return (
        <>
        <div id="contenedor">
            <div id="item1" style={{backgroundColor: "red", }}></div>
            <div id="item2" style={{backgroundColor: "green", }}></div>
            <div id="item3" style={{backgroundColor: "blue", }}></div>
        </div>
        </>
    )

}