const texto = $("texto");
const entrada = $("entrada");

entrada.oninput = () => {
  texto.innerText = entrada.value;
};

function $(elemento) {
  return document.getElementById(elemento);
}
