function onClickView() {
  const texto = document.getElementById("texto").value;
  alert(texto);
}

function onClickSet() {
  document.getElementById("texto").value = "Texto nuevo";
}
