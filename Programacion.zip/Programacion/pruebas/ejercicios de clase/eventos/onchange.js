/*function onChange(select) {
  alert(select);
}*/

function onChange() {
  alert(document.getElementById("selector").value);
}
