function onClickColor(boton) {
  document.getElementById("cube").style.background = boton.innerHTML;
  document.getElementById("cube").innerHTML = boton.innerHTML;
}

function onClickTamanio(boton) {
  document.getElementById("cube").style.width = boton.innerHTML;
  document.getElementById("cube").style.height = boton.innerHTML;
}
