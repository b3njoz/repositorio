function login() {
  const usuario = document.getElementById("nombre").value;
  const password = document.getElementById("password").value;

  if (usuario != "pepe" && password != "argento") {
    alert("Usuario o contraseña incorrectos");
    document.getElementById("nombre").value = "";
    document.getElementById("password").value = "";
  } else {
    alert("Bienvenido " + usuario);
    window.location.replace("http://www.google.com.ar");
  }
}

/*
const nombre = $("nombre");
const password = $("password");

ingresar.onclick = (e) => {
  if (nombre.value != "pepe" && password.value != "argento") {
    alert("Usuario o contraseña incorrectos");
  } else {
    alert("Bienvenido " + nombre.value);

  }
  e.preventDefault();
};

function $(elemento) {
  return document.getElementById(elemento);
}
*/
