const vector = [1, 2, 3, 4, 5, 6];

for (let i = 0; i < vector.length; i++) {
  const element = vector[i];
  console.log(element);
}

for (const i in vector) {
  console.log(vector[i]);
}

const frutas = ["manzana", "pera", "banana"];

frutas.forEach((element, index) => {
  console.log(element, index);
});

//agregar elemento
frutas.push("kiwi");

//eliminar el primer elemento
frutas.shift();

//eliminar el ultimo elemento
frutas.pop();

//agregar al inicio
frutas.unshift("naranja");

console.log(frutas);
