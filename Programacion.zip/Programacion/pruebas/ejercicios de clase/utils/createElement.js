function onTecla(texto) {
  addElement(texto);
}

function addElement(texto) {
  //creamos el elemento
  let newDiv = document.createElement("div");
  //agregamos la clase al elemento
  newDiv.classList.add("Salida");
  //seteamos el elemento del div
  newDiv.innerHTML = texto.value;
  //buscamos el div para ver la posicion para colocar el nuevo
  let currentDiv = document.getElementById("SalidaBox");
  //insertamos el nuevo elemento
  document.body.insertBefore(newDiv, currentDiv);
}
