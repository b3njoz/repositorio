/*const objetos = {
  nombre: "Juan",
  apellido: "Perez",
  edad: 30,
};

for (const i in objetos) {
  console.log(i);
}
*/

const frutas = [
  {
    nombre: "banana",
    cantidad: 5,
    precio: 50,
  },
  {
    nombre: "manzana",
    cantidad: 10,
    precio: 100,
  },
];

//recorrer
frutas.forEach((element) => {
  console.log("nombre:", element.nombre);
});
