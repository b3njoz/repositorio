const texto = $("texto");
const entrada = $("entrada");
const boton = $("boton");

//manera 2 de hacerlo
boton.onclick = () => {
  texto.innerText = entrada.value;
};

/*
Manera 1 de hacer el cambio con un escuchador de eventos
boton.addEventListener("click", () => {
  texto.innerText = entrada.value;
});
*/
function $(elemento) {
  return document.getElementById(elemento);
}
