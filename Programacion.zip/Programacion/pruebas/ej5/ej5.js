const selector = $("selector");
const selector2 = $("selector2");
const texto = $("texto");

selector.onchange = () => {
  texto.style.color = selector.value;
};

selector2.onchange = () => {
  texto.style.backgroundColor = selector2.value;
};

function $(elemento) {
  return document.getElementById(elemento);
}
