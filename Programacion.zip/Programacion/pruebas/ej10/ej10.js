const formulario = $("formulario");
const mensaje = $("mensaje");

formulario.onsubmit = (e) => {
  if (formulario["nombre"].value === "") {
    mensaje.textContent = "nombre vacio";
  } else if (formulario["apellido"].value === "") {
    mensaje.textContent = "apellido vacio";
  } else if (formulario["edad"].value === "") {
    mensaje.textContent = "edad vacia";
  } else {
    mensaje.style.color = "green";
    mensaje.textContent = `todo correcto`;
  }
  e.preventDefault();
};

function $(elemento) {
  return document.getElementById(elemento);
}
