/*const estatura = document.getElementById("estatura");
const peso = document.getElementById("peso");
const calcular = document.getElementById("calcular");

function calcularImc() {
  imc = peso.value / estatura.value ** 2;
  alert("tu indice de masa corporal es " + imc.toFixed(1));
}*/

const estatura = $("estatura");
const peso = $("peso");

calcular.onclick = () => {
  const imc = peso.value / estatura.value ** 2;
  return alert("Tu indice de masa corporal es: " + imc.toFixed(1));
};

function $(elemento) {
  return document.getElementById(elemento);
}
