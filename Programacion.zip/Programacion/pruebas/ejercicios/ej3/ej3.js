const nombre = $("nombre");
const apellido = $("apellido");
const edad = $("edad");
const altura = $("altura");
const correo = $("correo");
const mensaje = $("mensaje");

formulario.onsubmit = (e) => {
  if (nombre.value == "") {
    mensaje.innerText = "El campo nombre no puede estar vacio";
    mensaje.style.color = "red";
  } else if (apellido.value == "") {
    mensaje.innerText = "El campo apellido no puede estar vacio";
    mensaje.style.color = "red";
  } else if (edad.value < 0 || edad.value < 18) {
    mensaje.innerText = "El campo edad no debe ser negativo ni menor a 18";
    mensaje.style.color = "red";
  } else if (altura.value <= 0 || altura.value > 230) {
    mensaje.innerText = "El campo altura no debe ser negativo ni mayor a 230";
    mensaje.style.color = "red";
  } else {
    mensaje.innerText = "El formulario se envio correctamente";
    mensaje.style.color = "green";
  }
  e.preventDefault();
};

function $(elemento) {
  return document.getElementById(elemento);
}
