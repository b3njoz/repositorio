//inicializo las variables trayendolas desde el html con sus id con un jquery
const contador = $("contador");
const incrementar = $("incrementar");
const decrementar = $("decrementar");

//creo una funcion para tocar el boton
incrementar.onclick = () => {
  //pregunto si el contador es menor a 0
  if (contador.innerHTML < 20) {
    //realizo la suma al contador
    contador.innerHTML = parseInt(contador.innerHTML) + 1;
    console.log(contador.innerText);
    //pregunto si el contador es igual a 20, si es asi deshabilito incremento y habilito el decremento
  } else if (contador.innerHTML == 20) {
    incrementar.disabled = true;
    decrementar.disabled = false;
  }
};

decrementar.onclick = () => {
  if (contador.innerHTML > 0) {
    contador.innerHTML = parseInt(contador.innerHTML) - 2;
    console.log(contador.innerHTML);
  } else if (contador.innerHTML == 0) {
    incrementar.disabled = false;
    decrementar.disabled = true;
  }
};

function $(elemento) {
  return document.getElementById(elemento);
}
