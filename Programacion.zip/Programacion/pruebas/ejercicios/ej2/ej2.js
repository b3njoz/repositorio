const ladoA = $("ladoA");
const ladoB = $("ladoB");
const ladoC = $("ladoC");

calcular.onclick = () => {
  const altura = ladoA.value - ladoC.value;
  const areaTriang = (altura * ladoB.value) / 2;
  const areaRect = ladoB.value * altura;
  const areaTotal = areaRect + areaTriang;
  return alert("El area total es de: " + areaTotal);
};

function $(elemento) {
  return document.getElementById(elemento);
}
