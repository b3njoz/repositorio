const arreglo = ["benja", "luciana", "silvestre"];
const listado = $("listado");

// se puede hacer con un for donde hago un let i, que i vaya hasta la long del arreglo
for (let i = 0; i < arreglo.length; i++) {
  // creo un li y le agrego el texto del arreglo
  const item = document.createElement("li");
  item.textContent = arreglo[i];
  // lo agrego al listado con appendChild
  listado.appendChild(item);
}

//con un foreach se puede hacer lo mismo, poniendo el arreglo.foreach
/*arreglo.forEach((element) => {
  const item = document.createElement("li");
  item.textContent = element;
  listado.appendChild(item);
  console.log(element);
});*/

function $(elemento) {
  return document.getElementById(elemento);
}
