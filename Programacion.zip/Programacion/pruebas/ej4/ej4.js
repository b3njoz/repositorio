const base = $("base");
const altura = $("altura");
const botPer = $("botPer");
const botSup = $("botSup");

botPer.onclick = () => {
  perimetro = base.value * 2 + altura.value * 2;
  return alert("El perimetro es: " + perimetro);
};

botSup.onclick = () => {
  superficie = base.value * altura.value;
  return alert("La superficie es: " + superficie);
};

function $(elemento) {
  return document.getElementById(elemento);
}
