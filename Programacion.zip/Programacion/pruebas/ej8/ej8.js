const personas = [
  { nombre: "benja", apellido: "ortiz", edad: "24" },
  { nombre: "luciana", apellido: "soria", edad: "23" },
];

const lista = $("lista");

personas.forEach((element) => {
  const item = document.createElement("li");
  item.textContent = `${element.nombre} ${element.apellido}, ${element.edad}`;
  lista.appendChild(item);
});

function $(elemento) {
  return document.getElementById(elemento);
}
