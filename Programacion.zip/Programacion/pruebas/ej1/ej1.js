const mensaje = $("mensaje");

mensaje.innerText = "Hola mundo";

function $(elemento) {
  return document.getElementById(elemento);
}
