import { useState } from "react";
import "./App.css";
import MiComponente from "./MiComponente";
import Formulario from "./formulario";

function App() {
  const [contador, setContador] = useState(0);

  const incrementar = () => {
    setContador(contador + 1);
    console.log(contador);
  };

  const decrementar = () => {
    setContador(contador - 1);
    console.log(contador);
  };

  return (
    <>
      <h1>Contador</h1>
      <MiComponente mensaje={contador} />
      <button onClick={incrementar}>Incrementar</button>
      <button onClick={decrementar}>Decrementar</button>
      <Formulario nombre="mewing" apellido="Chad" />
    </>
  );
}

export default App;
