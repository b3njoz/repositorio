function MiComponente(props) {
  return (
    // eslint-disable-next-line react/prop-types
    <h1>{props.mensaje}</h1>
  );
}
export default MiComponente;
