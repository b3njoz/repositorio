import { useState } from "react";

const Formulario = (props) => {
  const [nombre, setNombre] = useState(props.nombre);
  const [apellido, setApellido] = useState(props.apellido);

  const nombreOnChange = (event) => {
    setNombre(event.target.value);
  };

  const apellidoOnChange = (event) => {
    setApellido(event.target.value);
  };

  const agregar = (e) => {
    e.preventDefault();
    console.log("nombre: " + nombre, "apellido: " + apellido);
  };

  return (
    <form onSubmit={agregar}>
      <label htmlFor="">Nombre</label>
      <input
        type="text"
        name="nombre"
        id="nombre"
        placeholder="Nombre"
        value={nombre}
        onChange={nombreOnChange}
      />
      <label htmlFor="">Apellido</label>
      <input
        type="text"
        name="apellido"
        id="apellido"
        placeholder="Apellido"
        value={apellido}
        onChange={apellidoOnChange}
      />
      <button type="submit">Agregar</button>
    </form>
  );
};

export default Formulario;
