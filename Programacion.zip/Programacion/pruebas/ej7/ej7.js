const formulario = $("formulario");
const nombre = $("nombre");
const listado = $("listado");

//creo el onsubmit con la funcion flecha con el e.preventDefault asi no se reinicia
formulario.onsubmit = (e) => {
  //este if verifica que la casilla del input no tenga nada para no agregar en blanco
  if (nombre.value != "") {
    const item = document.createElement("li");
    const itemName = nombre.value;
    item.textContent = itemName;
    //aca se vuelve a poner en blanco el input al agregar un dato
    nombre.value = "";
    //creo el boton para eliminar con su texto
    const eliminar = document.createElement("button");
    eliminar.textContent = "Eliminar";
    //creo el evento click para eliminar el item
    eliminar.onclick = () => {
      if (confirm(`desea eliminar el item? ${itemName}`)) {
        //el item remove borra el item que quiera
        item.remove();
      }
    };
    //con esto agrego el boton con el texto del listado
    item.appendChild(eliminar);
    listado.appendChild(item);
  }
  e.preventDefault();
};

function $(elemento) {
  return document.getElementById(elemento);
}
