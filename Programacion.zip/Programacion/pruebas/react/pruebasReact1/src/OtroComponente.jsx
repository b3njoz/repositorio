function Otro(props) {
  // eslint-disable-next-line react/prop-types
  return <p>{props.children}</p>;
}

export default Otro;
