import { useState } from "react";

function Contador() {
  const [contador, setContador] = useState(0);

  const incrementar = () => {
    setContador(contador + 1);
  };

  return (
    <>
      <p>{contador}</p>
      <button onClick={incrementar}>Incrementar</button>
      <button
        onClick={() => {
          setContador(contador - 1);
        }}
      >
        Decrementar
      </button>
    </>
  );
}

export default Contador;
