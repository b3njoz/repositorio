import { useState } from "react";
import Swal from "sweetalert2";

function PerSup() {
  const [base, setBase] = useState("");
  const [altura, setAltura] = useState("");

  const Superficie = () => {
    const superficie = base * altura;
    Swal.fire({
      title: `superficie ${superficie}`,
      text: "alto rectangulo",
      icon: "success",
    });
  };

  const Perimetro = () => {
    const perimetro = base * 2 + altura * 2;
    alert(`el perimetro es: ${perimetro}`);
  };

  return (
    <>
      <label htmlFor="">Ingrese Base</label>
      <input
        type="number"
        value={base}
        onChange={(e) => setBase(e.target.value)}
      />
      <label htmlFor="">Ingrese Altura</label>
      <input
        type="number"
        value={altura}
        onChange={(e) => setAltura(e.target.value)}
      />
      <button onClick={Superficie}>Superficie</button>
      <button onClick={Perimetro}>Perimetro</button>
    </>
  );
}

export default PerSup;
