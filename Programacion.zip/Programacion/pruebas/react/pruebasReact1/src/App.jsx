import MiComponente from "./MiComponente";
import Otro from "./OtroComponente";
import Contador from "./Contador";
import Entrada from "./Entrada";
import Numeros from "../Numeros";
import PerSup from "./PerSup";
import Select from "./Select";
import Lista from "./Lista";

function App() {
  const miMensaje = "desde app";
  return (
    <>
      <Contador></Contador>
      <MiComponente mensaje={miMensaje} />
      <MiComponente mensaje="props1" mensaje2="props2" />
      <Otro>Esto es children</Otro>
      <Entrada />
      <br />
      <Numeros />
      <br />
      <PerSup />
      <Select />
      <Lista />
    </>
  );
}

export default App;
