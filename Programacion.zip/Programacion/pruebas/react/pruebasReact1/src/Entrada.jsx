import { useState } from "react";
import Swal from "sweetalert2";

function Entrada() {
  const [texto, setTexto] = useState("");
  const [entrada, setEntrada] = useState("");

  const modificar = () => {
    setTexto(entrada);
    Swal.fire({
      title: "buen trabajo ",
      text: "You clicked the button!",
      icon: "success",
    });
  };

  return (
    <>
      <p>texto ingresado {texto}</p>
      <input
        type="text"
        name=""
        id=""
        value={entrada}
        onChange={(e) => setEntrada(e.target.value)}
      />
      <button onClick={modificar}>Modificar</button>
    </>
  );
}

export default Entrada;
