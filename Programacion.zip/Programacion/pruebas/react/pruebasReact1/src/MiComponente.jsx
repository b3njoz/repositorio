function MiComponente(props) {
  const { mensaje, mensaje2 } = props;
  return (
    <p>
      {mensaje} {mensaje2}
    </p>
  );
}

export default MiComponente;
