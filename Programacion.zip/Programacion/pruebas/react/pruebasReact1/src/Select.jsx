import { useState } from "react";

function Select() {
  const [colorTexto, setColorTexto] = useState("red");
  const [colorFondo, setColorFondo] = useState("white");

  return (
    <>
      <p style={{ color: colorTexto, backgroundColor: colorFondo }}>
        Texto de prueba
      </p>
      <select
        id="selector"
        value={colorTexto}
        onChange={(e) => setColorTexto(e.target.value)}
      >
        <option value="red">Red</option>
        <option value="green">Green</option>
        <option value="blue">Blue</option>
      </select>
      <select
        id="selector2"
        value={colorFondo}
        onChange={(e) => setColorFondo(e.target.value)}
      >
        <option value="red">Red</option>
        <option value="green">Green</option>
        <option value="blue">Blue</option>
      </select>
    </>
  );
}

export default Select;
