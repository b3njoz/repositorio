import { useState } from "react";

function Lista() {
  const [personas] = useState(["benja", "luciana", "silvestre", "serafina"]);
  return (
    <>
      <h1>Listado de Personas</h1>
      <ol>
        {personas.map((persona, index) => {
          return <li key={index}>{persona}</li>;
        })}
      </ol>
      <p>funciona????</p>
    </>
  );
}

export default Lista;
