/* eslint-disable react/prop-types */
import { useState } from "react";

function Numeros() {
  const [numero, setNumero] = useState(0);
  return (
    <>
      <input
        type="number"
        value={numero}
        onChange={(e) => {
          setNumero(Number(e.target.value));
        }}
      />
      <Signo numero={numero} />
      <Paridad numero={numero} />
    </>
  );
}

function Signo(props) {
  return (
    <>
      {props.numero > 0 && <p>es positivo</p>}
      {props.numero < 0 && <p>es negativo</p>}
      {props.numero === 0 && <p>es cero</p>}
    </>
  );
}

function Paridad(props) {
  return (
    <>
      {props.numero % 2 == 0 && <p>es par</p>}
      {props.numero % 2 != 0 && <p>es impar</p>}
    </>
  );
}

export default Numeros;
