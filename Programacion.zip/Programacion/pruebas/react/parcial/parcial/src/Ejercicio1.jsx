import { useState } from "react";

const Contraseña = () => {
  const [contraseña, setContraseña] = useState("");
  const [confirmContraseña, setConfirmContraseña] = useState("");
  const [validacion, setValidacion] = useState({
    longitud: false,
    numero: false,
    caracterEspecial: false,
    sinEspacio: false,
    coinciden: false,
  });

  const validarcontraseña = (contraseña, confirmContraseña) => {
    const longitud = contraseña.length >= 8;
    let numero = false;
    let caracterEspecial = false;
    let sinEspacio = true;

    for (let caracter of contraseña) {
      if ("0123456789".includes(caracter)) {
        numero = true;
      }
      if ("@!$%&#".includes(caracter)) {
        caracterEspecial = true;
      }
      if (caracter === " ") {
        sinEspacio = false;
      }
    }

    const coinciden = contraseña === confirmContraseña;

    setValidacion({
      longitud,
      numero,
      caracterEspecial,
      sinEspacio,
      coinciden,
    });
  };

  const handleContraseñaCambio = (e) => {
    const nuevaContraseña = e.target.value;
    setContraseña(nuevaContraseña);
    validarcontraseña(nuevaContraseña, confirmContraseña);
  };

  const handleConfirmarContraseñaCambio = (e) => {
    const nuevaConfirmContraseña = e.target.value;
    setConfirmContraseña(nuevaConfirmContraseña);
    validarcontraseña(contraseña, nuevaConfirmContraseña);
  };

  const todoValido = Object.values(validacion).every(Boolean);

  return (
    <div>
      <form>
        <div>
          <label>
            Contraseña:
            <input
              type="password"
              value={contraseña}
              onChange={handleContraseñaCambio}
            />
          </label>
        </div>
        <div>
          <label>
            Confirmar Contraseña:
            <input
              type="password"
              value={confirmContraseña}
              onChange={handleConfirmarContraseñaCambio}
            />
          </label>
        </div>
        <div>
          <p style={{ color: validacion.longitud ? "green" : "red" }}>
            {validacion.longitud ? "✓" : "✗"} La contraseña debe tener al menos
            8 caracteres
          </p>
          <p style={{ color: validacion.numero ? "green" : "red" }}>
            {validacion.numero ? "✓" : "✗"} La contraseña debe incluir al menos
            un número
          </p>
          <p style={{ color: validacion.caracterEspecial ? "green" : "red" }}>
            {validacion.caracterEspecial ? "✓" : "✗"} La contraseña debe incluir
            al menos un signo (@,!,$,%,&,#)
          </p>
          <p style={{ color: validacion.sinEspacio ? "green" : "red" }}>
            {validacion.sinEspacio ? "✓" : "✗"} La contraseña no debe contener
            espacios
          </p>
          <p style={{ color: validacion.coinciden ? "green" : "red" }}>
            {validacion.coinciden ? "✓" : "✗"} Las contraseñas deben coincidir
          </p>
        </div>
        <button
          type="button"
          disabled={!todoValido}
          onClick={() => alert("La contraseña es válida")}
        >
          Enviar
        </button>
      </form>
    </div>
  );
};

export default Contraseña;
