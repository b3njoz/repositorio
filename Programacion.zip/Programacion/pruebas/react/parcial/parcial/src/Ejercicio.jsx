import { useState } from "react";

function Listado() {
  const [nombre, setNombre] = useState("");
  const [edad, setEdad] = useState("");
  const [lista, setLista] = useState([]);
  const [mayor, setMayor] = useState(0);
  const [promedio, setPromedio] = useState(0);

  const handleAgregar = (e) => {
    if (nombre == "") {
      alert("Por favor ingrese un nombre");
      e.preventDefault();
    } else if (edad == "") {
      alert("Por favor ingrese una edad");
      e.preventDefault();
    } else {
      e.preventDefault();
      const nuevaPersona = {
        nombre,
        edad,
      };
      setLista([...lista, nuevaPersona]);
      setNombre("");
      setEdad("");
    }
  };

  const mayoriaEdad = () => {
    let contador = 0;
    lista.forEach((persona) => {
      if (persona.edad >= 18) {
        contador++;
      }
    });
    if (contador > 0) {
      setMayor(contador);
    } else {
      setMayor("No existen mayores de edad");
    }
  };

  const promedioEdad = () => {
    let suma = 0;
    lista.forEach((persona) => {
      suma += parseInt(persona.edad);
      console.log(suma);
    });
    setPromedio(`El promedio es ${suma / lista.length}`);
  };

  const mostrarDatos = () => {
    console.log(lista);
  };

  return (
    <>
      <form onSubmit={handleAgregar}>
        <label htmlFor="">Nombre</label>
        <input
          type="text"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        <label htmlFor="">Edad</label>
        <input
          type="number"
          value={edad}
          onChange={(e) => setEdad(e.target.value)}
        />
        <button>Agregar</button>
      </form>
      <ul>
        {lista.map((persona) => (
          <li key={persona.id}>
            nombre: {persona.nombre}, edad:{persona.edad}
          </li>
        ))}
      </ul>
      <button onClick={mostrarDatos}>Mostrar Datos</button>
      <br />
      <span>Cantidad de mayores:{mayor}</span>
      <button onClick={mayoriaEdad}>Ver</button>
      <br />
      <span>Promedio de edad:{promedio}</span>
      <button onClick={promedioEdad}>Ver</button>
    </>
  );
}

export default Listado;
