import Listado from "./Ejercicio";
import Contraseña from "./Ejercicio1";

function App() {
  return (
    <>
      <Listado></Listado>
      <Contraseña></Contraseña>
    </>
  );
}

export default App;
