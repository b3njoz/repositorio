import React from "react";

const ej1 = () => {
  return <div>console.log(object)</div>;
};

export default ej1;
console.log(object);
